Yêu cầu:
1. reskin button + icon. Em nhớ giữ size và kích thước content ben trong (png) để khi replace skin mới vo thi ui không bị lệch.
Các icon không cần thiết lắm (vi minh xai system icon cua ios). Chủ yếu focus button + home background + popup background + text font.
2. Em tham khao các screen shot roi vẽ thêm vào đó text nào cần dùng font nào rồi gởi kem font cho anh.
Thanks em.