var dragDiv:any;
var PORTRAIT = 1;
var LANDSCAPE = 2;
var dragIconPos:number;
var dragIntervalId:number;
var sizeHandlerId:number;

namespace cc
{
	export class Size
	{
		public width:number;
		public height:number;
		constructor(w:number = 0, h:number = 0)
		{
			this.width = w;
			this.height = h;
		}
	}
	export function size(w:number, h:number)
	{
		return new Size(w, h);
	}

	export namespace sys
	{
		var win = window, nav = win.navigator, doc = document, docEle = doc.documentElement;
		var ua = nav.userAgent.toLowerCase();

		export var isMobile:boolean;
		export var platform:number;
		export var os:string;
		export var osVersion:string;
		export var osMainVersion:number;
		export var browserType:string;
		export var browserVersion:string;

		// cocosjs -------------------------------------------------------------------------
		export var OS_IOS = "iOS";
	  export var OS_ANDROID = "Android";
	  export var OS_WINDOWS = "Windows";
	  export var OS_MARMALADE = "Marmalade";
	  export var OS_LINUX = "Linux";
	  export var OS_BADA = "Bada";
	  export var OS_BLACKBERRY = "Blackberry";
	  export var OS_OSX = "OS X";
	  export var OS_WP8 = "WP8";
	  export var OS_WINRT = "WINRT";
	  export var OS_UNIX = "UNIX";
	  export var OS_UNKNOWN = "Unknown";

	  export var UNKNOWN = -1;
	  export var WIN32 = 0;
	  export var LINUX = 1;
	  export var MACOS = 2;
	  export var ANDROID = 3;
	  export var IPHONE = 4;
	  export var IPAD = 5;
	  export var BLACKBERRY = 6;
	  export var NACL = 7;
	  export var EMSCRIPTEN = 8;
	  export var TIZEN = 9;
	  export var WINRT = 10;
	  export var WP8 = 11;

	  export var MOBILE_BROWSER = 100;
	  export var DESKTOP_BROWSER = 101;

	  export var BROWSER_TYPE_WECHAT = "wechat";
	  export var BROWSER_TYPE_ANDROID = "androidbrowser";
	  export var BROWSER_TYPE_IE = "ie";
	  export var BROWSER_TYPE_QQ = "qqbrowser";
	  export var BROWSER_TYPE_MOBILE_QQ = "mqqbrowser";
	  export var BROWSER_TYPE_UC = "ucbrowser";
	  export var BROWSER_TYPE_360 = "360browser";
	  export var BROWSER_TYPE_BAIDU_APP = "baiduboxapp";
	  export var BROWSER_TYPE_BAIDU = "baidubrowser";
	  export var BROWSER_TYPE_MAXTHON = "maxthon";
	  export var BROWSER_TYPE_OPERA = "opera";
	  export var BROWSER_TYPE_OUPENG = "oupeng";
	  export var BROWSER_TYPE_MIUI = "miuibrowser";
	  export var BROWSER_TYPE_FIREFOX = "firefox";
	  export var BROWSER_TYPE_SAFARI = "safari";
	  export var BROWSER_TYPE_CHROME = "chrome";
	  export var BROWSER_TYPE_LIEBAO = "liebao";
	  export var BROWSER_TYPE_QZONE = "qzone";
	  export var BROWSER_TYPE_SOUGOU = "sogou";
	  export var BROWSER_TYPE_UNKNOWN = "unknown";
		(function(){

			    // Get the os of system --
			    var isAndroid = false, iOS = false, osVersion = '', osMainVersion = 0;
			    var uaResult = /android (\d+(?:\.\d+)+)/i.exec(ua) || /android (\d+(?:\.\d+)+)/i.exec(nav.platform);
			    if (uaResult) {
			        isAndroid = true;
			        osVersion = uaResult[1] || '';
			        osMainVersion = parseInt(osVersion) || 0;
			    }
			    uaResult = /(iPad|iPhone|iPod).*OS ((\d+_?){2,3})/i.exec(ua);
			    if (uaResult) {
			        iOS = true;
			        osVersion = uaResult[2] || '';
			        osMainVersion = parseInt(osVersion) || 0;
			    }
			    else if (/(iPhone|iPad|iPod)/.exec(nav.platform)) {
			        iOS = true;
			        osVersion = '';
			        osMainVersion = 0;
			    }

			    var osName = sys.OS_UNKNOWN;
			    if (nav.appVersion.indexOf("Win") !== -1) osName = sys.OS_WINDOWS;
			    else if (iOS) osName = sys.OS_IOS;
			    else if (nav.appVersion.indexOf("Mac") !== -1) osName = sys.OS_OSX;
			    else if (nav.appVersion.indexOf("X11") !== -1 && nav.appVersion.indexOf("Linux") === -1) osName = sys.OS_UNIX;
			    else if (isAndroid) osName = sys.OS_ANDROID;
			    else if (nav.appVersion.indexOf("Linux") !== -1) osName = sys.OS_LINUX;
					sys.os = osName;
					sys.osVersion = osVersion;
	    		sys.osMainVersion = osMainVersion;

					// browser info -----------
	        var typeReg1 = /micromessenger|mqqbrowser|sogou|qzone|liebao|ucbrowser|360 aphone|360browser|baiduboxapp|baidubrowser|maxthon|mxbrowser|trident|miuibrowser/i;
	        var typeReg2 = /qqbrowser|chrome|safari|firefox|opr|oupeng|opera/i;
	        var browserTypes = typeReg1.exec(ua);
	        if(!browserTypes) browserTypes = typeReg2.exec(ua);
	        var browserType = browserTypes ? browserTypes[0] : sys.BROWSER_TYPE_UNKNOWN;
	        if (browserType === 'micromessenger')
	            browserType = sys.BROWSER_TYPE_WECHAT;
	        else if (browserType === "safari" && (ua.match(/android.*applewebkit/)))
	            browserType = sys.BROWSER_TYPE_ANDROID;
	        else if (browserType === "trident")
	            browserType = sys.BROWSER_TYPE_IE;
	        else if (browserType === "360 aphone")
	            browserType = sys.BROWSER_TYPE_360;
	        else if (browserType === "mxbrowser")
	            browserType = sys.BROWSER_TYPE_MAXTHON;
	        else if (browserType === "opr")
	            browserType = sys.BROWSER_TYPE_OPERA;

	        sys.browserType = browserType;
	    })();
		sys.isMobile = /mobile|android|iphone|ipad/.test(ua);
		sys.platform = sys.isMobile ? sys.MOBILE_BROWSER : sys.DESKTOP_BROWSER;

		sys.browserVersion = "";
	    /* Determine the browser version number */
	    (function(){
	        var versionReg1 = /(micromessenger|qq|mx|maxthon|baidu|sogou)(mobile)?(browser)?\/?([\d.]+)/i;
	        var versionReg2 = /(msie |rv:|firefox|chrome|ucbrowser|oupeng|opera|opr|safari|miui)(mobile)?(browser)?\/?([\d.]+)/i;
	        var tmp = ua.match(versionReg1);
	        if(!tmp) tmp = ua.match(versionReg2);
	        sys.browserVersion = tmp ? tmp[4] : "";
	    })();
	}
}

function trace(str:string)
{
	console.log(str);
}

function getOrientation():number
{
	return getScreenSize().width > getScreenSize().height ? LANDSCAPE : PORTRAIT;
}

function getSize(Name:string):number
{
  var size:number;
  var name = Name.toLowerCase();
  var document = window.document;
  var documentElement = document.documentElement;
	//trace("innerWidth " + window.innerWidth + " clientWidth " + window.document.documentElement.clientWidth + " scrollWidth " + window.document.documentElement.scrollWidth + " window.screen.width " + window.screen.width);
	//trace("innerHeight " + window.innerHeight + " clientHeight " + window.document.documentElement.clientHeight + " scrollHeight " + window.document.documentElement.scrollHeight  + " window.screen.height " + window.screen.height);

	if (window["inner" + Name] === undefined) {
    // IE6 & IE7 don't have window.innerWidth or innerHeight
    size = documentElement["client" + Name];
  }
  else {
    // Default to use window["inner" + Name]
    size = window["inner" + Name];
  }
  return size;
}

function getScreenSize():cc.Size
{
	return cc.size(getSize("Width"), getSize("Height"));
}

function getDragDiv():any
{
	if (dragDiv)
	{
		return dragDiv;
	}
	var drag:any = document.createElement('div');
	dragDiv = drag;
	drag.id = "drag";
	drag.style.position = 'absolute';
	drag.style.zIndex = 100;
	document.getElementsByTagName("body")[0].appendChild(drag);

	var img:any = document.createElement('img');
	img.src = "../../res/imgs/drag.png";
	img.id = "drag_img";
	img.style.height = "auto";
	img.style.display = 'none';
	drag.appendChild(img);
	return drag;
}

function checkShowingDrag()
{
	if (cc.sys.browserType == cc.sys.BROWSER_TYPE_UC && cc.sys.os != cc.sys.OS_IOS) return;
	// firefox auto fullscreen scroll
	if (cc.sys.browserType == cc.sys.BROWSER_TYPE_FIREFOX) return; // android
	if (!cc.sys.isMobile) return;
	// disable fullscreen trigger for ios
	//if (cc.sys.browserType == cc.sys.BROWSER_TYPE_SAFARI && getOrientation() == PORTRAIT) return;

	var drag = getDragDiv();
	// get device monitor size
	var ori = getOrientation();
	var sSize = getScreenSize();
	var sh = getOrientation() == PORTRAIT ? Math.max(screen.width, screen.height):Math.min(screen.width, screen.height);
	if (sSize.height < (ori == PORTRAIT ? sh*0.9 : sh*0.9))
	{
		// not full screen
		drag.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
		drag.style.width = sSize.width + 'px';
		drag.style.height = sh*1.8 + 'px';
		drag.style.zIndex = 100;
		drag.style.display = '';
		dragIconPos = sSize.height*0.5;
		document.getElementById('drag_img').style.marginTop = dragIconPos + 'px';
		document.getElementById('drag_img').style.display = '';
		document.getElementById('drag_img').style.width = Math.min(screen.width, screen.height)*0.25 + 'px';
		clearInterval(dragIntervalId);
		dragIntervalId = setInterval(this.onUpdate.bind(this), 1000/30);
		window.scrollTo(0, -1);
	}
	else {
			if (cc.sys.browserType == cc.sys.BROWSER_TYPE_SAFARI)
				drag.style.zIndex = -1;
			else drag.style.display = 'none';
			document.getElementById('drag_img').style.display = 'none';
			clearInterval(this.intervalId);
		}
}

function onUpdate()
{
	var sSize = getScreenSize();
	if (dragIconPos > sSize.height*0.3)
	{
		this.dragIconPos -= Math.min(sSize.width, sSize.height)/400;
	}
	else this.dragIconPos = sSize.height*0.5;

	document.getElementById('drag_img').style.marginTop = Math.round(dragIconPos) + 'px';
}

function sizeHandler()
{
	checkShowingDrag();
}

window.onresize = function()
{
	clearTimeout(sizeHandlerId);
	sizeHandlerId = setTimeout(sizeHandler, 100);
};
